<?php include 'includes\head.php';?>
<link rel="stylesheet" href="CSS/style.css">
<nav class="navbar navbar-expand-lg navbar-light bg-primary"  >
  <div class="container-fluid" >
    <a class="navbar-brand" href="dashboard.php">Bidyarthi Pustak Pasal</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-4 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="dashboard.php"><i class="fa fa-home"></i>Home</a>
          

        </li>
        <div>
          <li class="nav-item"  >
          <a class="nav-link active" aria-current="page" href="index.php" style="padding-right:200px;"><i class="fa fa-home"></i>logout</a>
          

        </li>
        </div>
        
     
       
      </div>
      <div class="jumbotron" style="text-align:right;">
          <h4>WELCOME ADMIN </h4>         
        </div>

        
        <!-- <li>
      <a class="nav-link active" href="index.php" ><i class="fa fa-sign-out"></i>log out</a>
      </li> -->
    </ul>
    </div>
  </div>
</nav>
