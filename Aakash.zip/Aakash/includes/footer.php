<div class="clearfix"></div>
<footer class="site-footer">
	<div class="footer-inner bg-white">
		<div class="row">
			<div class="col-sm-6">
					COPYRIGHT &copy; 2021 BIDYARTHI PUSTAK PASAL
				</div>
				
			</div>
		</div>
	</footer>
	<?php include 'includes\head.php';



	?>
